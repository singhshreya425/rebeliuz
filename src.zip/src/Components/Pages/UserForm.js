import React, { useState } from 'react';
import "./UserForm.css"
import { useSelector , useDispatch } from 'react-redux';
import { AddUserData } from '../Redux/UserSlice';

const UserForm = ()=>{
    const dispatch = useDispatch()
    const [form, setForm] = useState({
        name: '',
        email: '',
        address: '',
        dob: ''
      });
      const [errors, setErrors] = useState({});
    
      const validate = () => {
        let tempErrors = {};
        tempErrors.name = form.name ? "" : "This field is required.";
        tempErrors.email = (form.email ? "" : "This field is required.") || 
                           (/^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/.test(form.email) ? "" : "Email is not valid.");
        tempErrors.address = form.address ? "" : "This field is required.";
        tempErrors.dob = form.dob ? "" : "This field is required.";
    
        setErrors({
          ...tempErrors
        });
    
        return Object.values(tempErrors).every(x => x === "");
      }
    
      const handleInputChange = e => {
        const { name, value } = e.target;
        setForm({
          ...form,
          [name]: value
        });
      };
    
      const handleSubmit = e => {
        e.preventDefault();
        if (validate()) {
          setForm({
            name: '',
            email: '',
            address: '',
            dob: ''
          });
          dispatch(AddUserData(form))
        }
      };
    
      return (
        <div className="container">
          <form onSubmit={handleSubmit}>
            <div>
              <label>Name:</label>
              <input type="text" name="name" value={form.name} onChange={handleInputChange} />
              {errors.name && <div className="error">{errors.name}</div>}
            </div>
            <div>
              <label>Email:</label>
              <input type="email" name="email" value={form.email} onChange={handleInputChange} />
              {errors.email && <div className="error">{errors.email}</div>}
            </div>
            <div>
              <label>Address:</label>
              <input type="text" name="address" value={form.address} onChange={handleInputChange} />
              {errors.address && <div className="error">{errors.address}</div>}
            </div>
            <div>
              <label>DOB:</label>
              <input type="date" name="dob" value={form.dob} onChange={handleInputChange} />
              {errors.dob && <div className="error">{errors.dob}</div>}
            </div>
            <button type="submit">Submit</button>
          </form>
        </div>
      );
}

export default UserForm