import React, { useState } from 'react';
import './UserTable.css';
import { useDispatch, useSelector } from 'react-redux';


const UserTable = ()=>{
    let UserList = useSelector((e)=> e.User.UserArray)
    console.log('UserList==> ', UserList)
    const data = [
        {
          name: 'John Doe',
          email: 'john@example.com',
          address: '123 Main St',
          dob: '1990-01-01'
        },
        // More data...
      ];
    return (
        <table className="table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Address</th>
              <th>DOB</th>
            </tr>
          </thead>
          <tbody>
            {UserList && UserList.map((item, index) => (
              <tr key={index}>
                <td>{item.name}</td>
                <td>{item.email}</td>
                <td>{item.address}</td>
                <td>{item.dob}</td>
              </tr>
            ))}
          </tbody>
        </table>
      );
}

export default UserTable